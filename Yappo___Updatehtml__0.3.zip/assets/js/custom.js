jQuery(document).ready(function(){ 

	// Mobile menu
	$('.nav-icon').click(function () {
		$('.mobile_menu').toggleClass('canvas-menu');
		return false;

	});
	$('.mobile_menu ul li a').click(function () {
		$('.mobile_menu').toggleClass('canvas-menu');

	});

	

		
		
	

});